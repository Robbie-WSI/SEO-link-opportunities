window.hjSiteSettings = window.hjSiteSettings || {
    "site_id": 3113882,
    "r": 0.3767439525462963,
    "rec_value": 0.10999999999999989,
    "state_change_listen_mode": "automatic",
    "record": true,
    "continuous_capture_enabled": true,
    "recording_capture_keystrokes": true,
    "session_capture_console_consent": false,
    "anonymize_digits": true,
    "anonymize_emails": true,
    "suppress_all": false,
    "suppress_all_on_specific_pages": [],
    "suppress_text": false,
    "suppress_location": false,
    "user_attributes_enabled": false,
    "legal_name": null,
    "privacy_policy_url": null,
    "deferred_page_contents": [],
    "record_targeting_rules": [],
    "feedback_widgets": [{
        "id": 408057,
        "created_epoch_time": 1660824360,
        "effective_show_branding": true,
        "skin": "light",
        "background": "#f4364c",
        "position": "middle_right",
        "content": {
            "comment_footer": "<p><strong>Heads up! This is for feedback only.</strong></p><p>Need help? Complete the form here repromed.ie/contact-us</p>",
            "email": "We may wish to follow up. Enter your email if you're happy for us to contact you.",
            "emotion": "Hi there👋, How would you rate your experience with our website?",
            "initial": "Help us improve by sharing your feedback.",
            "thankyou": "Thank you for sharing your feedback with us!"
        },
        "connect_visit_data": "always",
        "language": "en",
        "display_condition": "immediate",
        "display_delay": 0,
        "persist_condition": "always",
        "auto_screenshot": true,
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "contains",
            "negate": false,
            "pattern": "/",
            "name": null,
            "rule_type": null
        }],
        "ask_for_consent": false,
        "emotion_style": "default",
        "display_type": "button",
        "show_legal": false,
        "widget_label": null,
        "active_seasonal_emotion_style": null,
        "parent_element_selector": null
    }],
    "heatmaps": [],
    "polls": [{
        "id": 835793,
        "created_epoch_time": 1660824816,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": true,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "labels": [{
                    "text": "Not satisfied at all"
                }, {
                    "text": "Very satisfied"
                }],
                "next": "byOrder",
                "nextIfSkipped": "byOrder",
                "required": false,
                "scaleCount": 5,
                "text": "Hi😊, how easy was it to complete your booking?",
                "type": "rating-scale-5",
                "uuid": "00d7cba0-1e6a-4829-948e-508b965d074a"
            }, {
                "next": "byOrder",
                "nextIfSkipped": "byOrder",
                "required": false,
                "text": "What's the reason for your score?",
                "type": "single-open-ended-multiple-line",
                "uuid": "a8da535d-02d4-4816-8641-e05be9c5c2da"
            }, {
                "next": "byOrder",
                "nextIfSkipped": "byOrder",
                "required": false,
                "text": "What made you buy from us today?",
                "type": "single-open-ended-multiple-line",
                "uuid": "826a7e5b-87c0-4c2f-81f9-f3b5e9bf6d0a"
            }],
            "thankyou": "😍 Thank you for answering this survey. Your feedback is highly appreciated!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "delay",
        "display_delay": 3,
        "persist_condition": "always",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": false,
            "pattern": "https://repromed.ie/booking/?payment=success",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "phone",
            "name": null,
            "rule_type": null
        }],
        "uuid": "1d048dc9-202b-4ab5-b486-215090034cf3",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "popover",
        "show_legal": false,
        "logo_url": null,
        "button_color": "#324FBE",
        "parent_element_selector": null
    }, {
        "id": 835792,
        "created_epoch_time": 1660824544,
        "skin": "light",
        "background": "#FFFFFF",
        "effective_show_branding": true,
        "position": "right",
        "content": {
            "version": 2,
            "questions": [{
                "answers": [{
                    "comments": false,
                    "text": "I didn't find what I was looking for"
                }, {
                    "comments": false,
                    "text": "I didn't find the website easy to use"
                }, {
                    "comments": false,
                    "text": "It was too expensive for me"
                }, {
                    "comments": false,
                    "text": "There are few available dates"
                }, {
                    "comments": false,
                    "text": "I need more time to gather my medical answers"
                }, {
                    "comments": false,
                    "text": "The payment wasn't processed."
                }, {
                    "comments": true,
                    "text": "Something else"
                }],
                "next": "byOrder",
                "nextIfSkipped": "byOrder",
                "pin_last_to_bottom": true,
                "randomize_answer_order": true,
                "required": false,
                "text": "We're sorry to see you go!🥺 What's your reason for leaving? ",
                "type": "multiple-close-ended",
                "uuid": "78942292-cbf6-4667-b902-2104d3234c33"
            }, {
                "next": "byOrder",
                "nextIfSkipped": "byOrder",
                "required": false,
                "text": "What could we do to improve?",
                "type": "single-open-ended-multiple-line",
                "uuid": "4cc7f7b0-7eb7-416a-b574-9bfe1e53036e"
            }],
            "thankyou": "Thank you for answering this survey. Your feedback is highly appreciated!"
        },
        "connect_visit_data": "always",
        "ask_for_consent": false,
        "language": "en",
        "display_condition": "abandon",
        "display_delay": 0,
        "persist_condition": "once",
        "targeting_percentage": 100,
        "targeting": [{
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "tablet",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "simple",
            "negate": false,
            "pattern": "https://repromed.ie/booking/",
            "name": null,
            "rule_type": null
        }, {
            "component": "device",
            "match_operation": "exact",
            "negate": false,
            "pattern": "desktop",
            "name": null,
            "rule_type": null
        }, {
            "component": "url",
            "match_operation": "exact",
            "negate": true,
            "pattern": "https://repromed.ie/booking/?payment=success",
            "name": null,
            "rule_type": null
        }],
        "uuid": "fd7619d8-b32b-4ee6-a9c3-b2f36d42428f",
        "invite": {
            "title": "Your feedback is important to us!",
            "description": "Tell us what you think about this page by taking our quick Survey.",
            "button": "Yes, I will give feedback",
            "close": "No thanks"
        },
        "invite_enabled": false,
        "display_type": "full_screen",
        "show_legal": false,
        "logo_url": null,
        "button_color": "#324FBE",
        "parent_element_selector": null
    }],
    "integrations": {
        "optimizely": {
            "tag_recordings": false
        },
        "abtasty": {
            "tag_recordings": false
        },
        "mixpanel": {
            "send_events": false
        },
        "unbounce": {
            "tag_recordings": false
        },
        "google_optimize": {
            "tag_recordings": false
        },
        "hubspot": {
            "enabled": false,
            "send_recordings": false,
            "send_surveys": false
        }
    },
    "features": ["survey.embeddable_widget", "feedback.embeddable_widget", "client_script.compression.pc", "error_reporting", "ask.popover_redesign", "survey.image_question", "settings.billing_v2", "survey.type_button", "survey.screenshots", "feedback.widgetV2"],
    "tracking_code_verified": true
};

! function() {
    "use strict";

    function e(t) {
        return e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        }, e(t)
    }

    function t(e, t) {
        for (var r = 0; r < t.length; r++) {
            var i = t[r];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, n(i.key), i)
        }
    }

    function n(t) {
        var n = function(t, n) {
            if ("object" != e(t) || !t) return t;
            var r = t[Symbol.toPrimitive];
            if (void 0 !== r) {
                var i = r.call(t, "string");
                if ("object" != e(i)) return i;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return String(t)
        }(t);
        return "symbol" == e(n) ? n : String(n)
    }
    var r, i = function() {
        function e(t) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10,
                r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1e3;
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e), this.send = t, this.batchSize = n, this.flushInterval = r, this.buffer = [], this.flushTimer = null
        }
        var n, r;
        return n = e, (r = [{
            key: "getBuffer",
            value: function() {
                return this.buffer
            }
        }, {
            key: "add",
            value: function(e) {
                var t = this;
                this.buffer.push(e), this.buffer.length >= this.batchSize ? this.flush() : this.flushTimer || (this.flushTimer = setTimeout((function() {
                    t.flush()
                }), this.flushInterval))
            }
        }, {
            key: "flush",
            value: function() {
                this.buffer.length > 0 && (this.send(this.buffer), this.buffer = []), this.flushTimer && (clearTimeout(this.flushTimer), this.flushTimer = null)
            }
        }]) && t(n.prototype, r), Object.defineProperty(n, "prototype", {
            writable: !1
        }), e
    }();

    function s() {
        return s = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
            }
            return e
        }, s.apply(this, arguments)
    }
    var a, o, c, u = function() {
            try {
                return "performance" in window && "now" in window.performance
            } catch (e) {
                return !1
            }
        },
        l = {
            version: 6,
            metricsUrl: (null === (r = window._hjSettings) || void 0 === r ? void 0 : r.metricsUrl) || "https://metrics.hotjar.io",
            sampling: {
                metrics: .1,
                fieldMetrics: .01,
                debug: .5,
                universalDebug: .05 * .1
            },
            browser: {
                hasPerformance: !1,
                shouldLogMetrics: !1,
                inLab: !1
            },
            buffer: {
                bufferSize: 40,
                flushInterval: 3e3
            }
        },
        d = {
            isDebugEnabled: !1,
            isMetricsEnabled: !1,
            isFieldMetricsEnabled: !1,
            loggedMetrics: {},
            genericTags: {}
        },
        f = function(e, t, n) {
            var r;
            d.loggedMetrics[e] = s(s({}, d.loggedMetrics[e]), {}, ((r = {})[t] = n || {}, r))
        },
        h = function(e) {
            if (!e) return "value";
            var t = Object.keys(e)[0];
            return t && e[t] || "value"
        },
        g = function(e) {
            var t, n = null !== (t = e.tag) && void 0 !== t ? t : void 0;
            return d.isDebugEnabled ? s(s(s({}, n), e.extraTags), d.genericTags) : n
        },
        p = function(e, t) {
            if (!a) return !1;
            var n = d.isMetricsEnabled || d.isDebugEnabled;
            return "lab" === e && (n = l.browser.inLab), "field" === e && (n = d.isFieldMetricsEnabled), t ? n && t.flush : n
        },
        m = function(e) {
            var t = !1,
                n = "v=".concat(l.version),
                r = "".concat(l.metricsUrl, "?").concat(n, "&site_id=").concat(window.hjSiteSettings.site_id) + (d.isDebugEnabled ? "&debug=true" : ""),
                i = JSON.stringify(e);
            if ("sendBeacon" in navigator) try {
                t = navigator.sendBeacon.bind(navigator)(r, i)
            } catch (e) {}
            if (!1 === t) try {
                var s = new XMLHttpRequest;
                s.open("POST", r), s.timeout = 1e4, s.send(i)
            } catch (e) {}
            l.browser.shouldLogMetrics && console.debug("New Metrics: ", e)
        },
        b = {
            getConfig: function(e) {
                return l[e]
            },
            getState: function(e) {
                return d[e]
            },
            start: function() {
                try {
                    l.browser = {
                        hasPerformance: u(),
                        shouldLogMetrics: /hjMetrics=1/.test(location.search),
                        inLab: /hjLab=true/.test(location.search)
                    };
                    var e = b.time(),
                        t = window.hjSiteSettings || {},
                        n = t.features,
                        r = t.site_id,
                        s = new Set(n),
                        o = l.sampling;
                    return d.genericTags = {
                        site_id: r
                    }, d.isDebugEnabled = Math.random() <= o.universalDebug || s.has("client_script.metrics.debug") && Math.random() <= o.debug, d.isMetricsEnabled = Math.random() <= o.metrics, d.isFieldMetricsEnabled = d.isMetricsEnabled && Math.random() <= o.fieldMetrics, a = new i(m, l.buffer.bufferSize, l.buffer.flushInterval), e
                } catch (e) {
                    console.debug("Error in metrics.start", {
                        error: e
                    })
                }
            },
            reset: function() {
                d.loggedMetrics = {}
            },
            stop: function() {
                d.isDebugEnabled = !1, d.isMetricsEnabled = !1, d.genericTags = {}
            },
            count: function(e, t) {
                var n = t.incr,
                    r = t.tag,
                    i = t.extraTags,
                    o = t.type;
                try {
                    var c, u = h(r),
                        l = d.loggedMetrics[e],
                        f = 0;
                    if (n ? (f = (l && l[u] || 0) + (n.value || 1), d.loggedMetrics[e] = s(s({}, l), {}, ((c = {})[u] = null != n && n.flush ? 0 : f, c))) : f = 1, p(o, n)) {
                        var m = {
                            name: e,
                            type: "count",
                            value: f,
                            tags: g({
                                tag: r,
                                extraTags: i
                            })
                        };
                        a.add(m)
                    }
                } catch (e) {}
            },
            distr: function(e, t) {
                var n = t.task,
                    r = t.value,
                    i = t.extraTags;
                p() && a.add({
                    name: e,
                    type: "distribution",
                    value: r,
                    tags: g({
                        tag: {
                            task: n
                        },
                        extraTags: i
                    })
                })
            },
            time: function() {
                try {
                    if (!l.browser.hasPerformance) return;
                    return performance.now()
                } catch (e) {}
            },
            timeEnd: function(e, t) {
                var n = t.tag,
                    r = t.start,
                    i = t.total,
                    s = t.extraTags,
                    o = t.type;
                try {
                    var c = b.time();
                    if (!i && !c) return;
                    var u = h(n),
                        l = i || (r && c ? c - r : void 0);
                    if (f(e, u, {}), l && l > 0 && p(o)) {
                        var d = {
                            name: e,
                            type: "distribution",
                            value: Math.round(l),
                            tags: g({
                                tag: n,
                                extraTags: s
                            })
                        };
                        a.add(d)
                    }
                    return c
                } catch (t) {
                    console.debug("Failed to send timer metric: ", {
                        name: e,
                        tag: n,
                        error: t
                    })
                }
            },
            timeIncr: function(e, t) {
                var n, r, i, s, a = t.tag,
                    o = t.start,
                    c = t.flush,
                    u = t.extraTags,
                    l = t.type,
                    g = hj.metrics.time(),
                    p = o && g ? g - o : void 0,
                    m = (n = e, {
                        tagName: r = h(a),
                        start: (s = (i = d.loggedMetrics[n]) && i[r] || {}).start,
                        total: s.total
                    }),
                    v = p ? p + (m.total || 0) : m.total;
                return f(e, m.tagName, {
                    total: v
                }), c && b.timeEnd(e, {
                    tag: a,
                    total: v,
                    extraTags: u,
                    type: l
                }), v
            },
            timeWatcher: function() {
                var e, t = 0,
                    n = !1,
                    r = function() {
                        var n, r = b.time();
                        return t += null !== (n = e && r && r - e) && void 0 !== n ? n : 0, e = b.time(), t
                    };
                return {
                    start: function() {
                        if (!n) return n = !0, e = b.time()
                    },
                    incr: r,
                    end: function() {
                        var n = r();
                        return t = 0, e = void 0, n
                    }
                }
            },
            getErrorMessage: function(e) {
                return e instanceof Error ? e.message : "string" == typeof e ? e : ""
            }
        };
    window.hj = window.hj || function() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        (window.hj.q = window.hj.q || []).push(t)
    }, window.hj.metrics = b;
    var v, w, j, _, y, S, E = hj.metrics.start(),
        T = !(!window.CS_CONF || null === (o = window.CS_CONF.voc) || void 0 === o || !o.enabled),
        M = !(window.CS_CONF || !(null !== (c = window.hjSiteSettings.features) && void 0 !== c && c.includes("cs_lite") || window._hjSettings.csid));
    if (window.hjLazyModules = window.hjLazyModules || {
            SURVEY_V2: {
                js: "survey-v2.85e53683cf6cb5d13d3b.js"
            },
            SURVEY_BOOTSTRAPPER: {
                js: "survey-bootstrapper.1db817a3108bf3677001.js"
            },
            SURVEY_ISOLATED: {
                js: "survey-isolated.b69c5a6d17f1ac970011.js"
            },
            HEATMAP_RETAKER: {
                js: "heatmap-retaker.f79c0c7bb13d8a14bddc.js"
            },
            SURVEY_INVITATION: {
                js: "survey-invitation.c2c4e967aff784353cdf.js"
            },
            NOTIFICATION: {
                js: "notification.86732657079a99e6ce8a.js"
            },
            PREACT_INCOMING_FEEDBACK: {
                js: "preact-incoming-feedback.e210ce19e1095e1414ea.js"
            },
            SENTRY: {
                js: "sentry.58c81e3e25532810f6fd.js"
            },
            BROWSER_PERF: {
                js: "browser-perf.8417c6bba72228fa2e29.js"
            },
            USER_TEST: {
                js: "user-test.7a6f897e283409dbfa84.js"
            }
        }, T) window._uxa.push(["start:hotjar", window.hjSiteSettings]);
    else if (M) {
        window.CS_CONF_BASE = (S = (y = (v = window.hjSiteSettings).suppress_all || v.suppress_text || (null === (w = v.suppress_all_on_specific_pages) || void 0 === w ? void 0 : w.length)) ? function(e) {
            var t, n, r, i, s, a;
            if ((e.suppress_all || e.suppress_text) && (n = ".*"), null !== (t = e.suppress_all_on_specific_pages) && void 0 !== t && t.length) {
                var o = e.suppress_all_on_specific_pages.find((function(e) {
                    return "regex" === e.match_operation
                }));
                o && (n = null == o ? void 0 : o.pattern), i = e.suppress_all_on_specific_pages, s = {
                    contains: "contain",
                    ends_with: "end",
                    exact: "exact",
                    simple: "contain",
                    starts_with: "start"
                }, r = (a = i.filter((function(e) {
                    return Object.keys(s).includes(e.match_operation)
                })).map((function(e) {
                    return {
                        operator: s[e.match_operation],
                        value: e.pattern,
                        ignoreQueryParams: "simple" === e.match_operation,
                        ignoreURIFragments: "simple" === e.match_operation,
                        ignoreCaseSensitivity: "simple" === e.match_operation,
                        notOperator: e.negate
                    }
                }))).length ? a : void 0
            }
            return {
                replayRecordingMaskedUrlRegex: n,
                replayRecordingMaskedUrlRegexRules: r
            }
        }(v) : null, {
            projectId: v.cs_project_id,
            hostnames: [window.location.hostname],
            sampleRate: v.continuous_capture_enabled ? 100 : 100 * v.rec_value,
            replayRecordingRate: v.record ? 100 : 0,
            jsErrorsEnabled: v.session_capture_console_consent,
            customError: v.session_capture_console_consent && {
                enabled: !0,
                consoleMessageLogLevels: ["error"]
            },
            voc: null !== (j = v.feedback_widgets) && void 0 !== j && j.length || null !== (_ = v.polls) && void 0 !== _ && _.length ? {
                enabled: 1,
                siteId: v.site_id
            } : {
                enabled: 0
            },
            whitelistedAttributes: !y && v.recording_capture_keystrokes ? ["data-hj-allow"] : [],
            anonymisationMethod: S,
            anonymizeDigits: !!y || v.anonymize_digits,
            anonymizeEmails: !!y || v.anonymize_emails
        }), window._uxa = window._uxa || [];
        var R = window._hjSettings.environment,
            O = "t.contentsquare.net";
        R && "live" !== R && (window._hjSettings.csid && (window.CS_CONF_BASE.projectId = window._hjSettings.csid), O = "t-staging.contentsquare.net");
        var x = document.createElement("script");
        x.type = "text/javascript", x.async = !0, x.src = "//".concat(O, "/uxa/smb/tag.js"), document.getElementsByTagName("head")[0].appendChild(x)
    } else window.hjBootstrap = window.hjBootstrap || function(e, t, n) {
        var r, i = new RegExp("bot|google|headless|baidu|bing|msn|duckduckbot|teoma|slurp|yandex|phantomjs|pingdom|ahrefsbot|facebook", "i"),
            s = (null === (r = window.navigator) || void 0 === r ? void 0 : r.userAgent) || "unknown";
        if (i.test(s)) return hj.metrics.count("session-rejection", {
            tag: {
                reason: "bot"
            }
        }), void console.warn("Hotjar not launching due to suspicious userAgent:", s);
        var a = "http:" === window.location.protocol,
            o = Boolean(window._hjSettings.preview);
        if (a && !o) return hj.metrics.count("session-rejection", {
            tag: {
                reason: "https"
            }
        }), void console.warn("For security reasons, Hotjar only works over HTTPS. Learn more: https://help.hotjar.com/hc/en-us/articles/115011624047");
        var c = function(e, t, n) {
            window.hjBootstrapCalled = (window.hjBootstrapCalled || []).concat(n), window.hj && window.hj._init && window.hj._init._verifyInstallation && hj._init._verifyInstallation()
        };
        c(0, 0, n);
        var u = window.document,
            l = u.head || u.getElementsByTagName("head")[0];
        hj.scriptDomain = e;
        var d = u.createElement("script");
        d.async = 1, d.src = hj.scriptDomain + t, d.charset = "utf-8", l.appendChild(d), c.revision = "1c457c7", window.hjBootstrap = c
    }, window.hjBootstrap("https://script.hotjar.com/", "modules.8da33a8f469c3b5ffcec.js", "3113882"), hj.metrics.timeEnd("resource-blocking-time", {
        tag: {
            resource: "hotjar-js"
        },
        start: E,
        type: "lab"
    })
}();